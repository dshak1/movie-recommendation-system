export interface Movie {
  title: string
  overview: string
  vote_average: number
  vote_count: number
  score?: number
}
